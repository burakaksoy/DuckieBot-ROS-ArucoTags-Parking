#!/usr/bin/env python
import rospy
import math
from duckietown_msgs.msg import  Twist2DStamped
from geometry_msgs.msg import PoseStamped

class aruco_stopper(object):
    def __init__(self):
        self.node_name = rospy.get_name()
        
        self.pub_counter = 0
        
        # Setup Parameters
            # WE DO NOT HAVE ANY
        
        # Publications
        self.pub_car_cmd = rospy.Publisher("/duckiepark/lane_controller_node/car_cmd",Twist2DStamped,queue_size=1)
        
        # Subscriptions
        self.stop_tag = rospy.Subscriber("/aruco_single/pose", PoseStamped,self.at_stop_tag, queue_size=1) # NOT SURE FOR THE TOPIC NAME
        
        # safe shutdown
        rospy.on_shutdown(self.custom_shutdown)
        
        
    def at_stop_tag(self,msg):
        car_control_msg = Twist2DStamped()
        if (msg.pose.position.z < 0.15):
            car_control_msg.header = msg.header
            car_control_msg.v = 0.0
            car_control_msg.omega=0.0
            self.publishCmd(car_control_msg)
            rospy.sleep(0.5) #To make sure that it gets published.
            
    def custom_shutdown(self):
        rospy.loginfo("[%s] Shutting down..." %self.node_name)
        
        # Stop listening
        self.stop_tag.unregister()

        # Send stop command
        car_control_msg = Twist2DStamped()
        car_control_msg.v = 0.0
        car_control_msg.omega = 0.0
        self.publishCmd(car_control_msg)
        rospy.sleep(0.5) #To make sure that it gets published.
        rospy.loginfo("[%s] Shutdown" %self.node_name)
        
if __name__ == "__main__":
    rospy.init_node("aruco_stopper",anonymous=False)
    detect_aruco_stop = aruco_stopper()
    rospy.spin()
